# Study Hub — iPhone 설치 가이드

## 사전 준비

PWA(홈화면 앱)로 설치하려면 **HTTPS 웹서버**가 필요해. 로컬 파일로는 iPhone에 설치할 수 없어. 무료로 쓸 수 있는 세 가지 방법을 난이도 순으로 정리했어.

---

## 방법 1: Netlify Drop (가장 쉬움, 5분)

회원가입 없이 폴더만 드래그하면 끝.

1. PC에서 https://app.netlify.com/drop 접속
2. `study-hub` 폴더(또는 압축 푼 폴더) 통째로 페이지에 드래그&드롭
3. 잠시 후 `https://랜덤이름.netlify.app` 주소가 나옴
4. 그 주소를 iPhone Safari에서 열기
5. 하단 공유 버튼(↑) → **홈 화면에 추가** → 추가

장점: 가입 불필요, 즉시 배포
단점: 주소가 랜덤 (계정 만들면 원하는 이름으로 변경 가능)

---

## 방법 2: GitHub Pages (영구 사용, 가입 필요)

1. https://github.com 가입
2. 우측 상단 + → **New repository**
3. 이름: `study-hub`, **Public**, Create
4. 만든 저장소에서 **Add file → Upload files** 클릭
5. 모든 파일을 드래그해서 업로드 → Commit
6. **Settings → Pages**
7. Source: `Deploy from a branch`, Branch: `main` / `/(root)` → Save
8. 몇 분 후 `https://[계정명].github.io/study-hub/` 주소가 활성화됨
9. iPhone Safari에서 그 주소 열기 → 공유 → 홈 화면에 추가

장점: 무료, 영구 사용, 주소 고정
단점: GitHub 가입 필요

---

## 방법 3: 같은 Wi-Fi에서 임시 사용 (설치 없이 테스트)

PC와 iPhone이 같은 Wi-Fi에 있을 때 임시로 쓸 수 있어. 설치는 안 되지만 작동은 확인할 수 있어.

**PC가 macOS / Linux:**
```bash
cd study-hub
python3 -m http.server 8000
```

**PC가 Windows (PowerShell):**
```powershell
cd study-hub
python -m http.server 8000
```

그 다음:
1. PC에서 명령 프롬프트에 `ipconfig`(Windows) 또는 `ifconfig`(Mac) 입력 → 192.168.x.x 형태의 IP 확인
2. iPhone Safari에서 `http://192.168.x.x:8000` 접속
3. 그냥 사용 (이 방법은 HTTPS가 아니어서 홈 화면 추가는 가능하지만 PWA 오프라인 기능은 제한)

장점: 가입·업로드 불필요
단점: PC가 켜져 있고 같은 Wi-Fi여야 함, 오프라인 작동 제한

---

## 설치 후 사용 팁

- 홈 화면 아이콘으로 실행하면 주소창 없는 전체 화면 앱처럼 작동
- 데이터는 iPhone에 자동 저장되며 오프라인에서도 작동
- **중요**: Safari 브라우저와 홈화면 PWA는 **데이터가 분리**됨. PWA 설치 후엔 PWA에서만 사용
- 백업: 대시보드 하단 **JSON 내보내기**로 파일 저장 → 메일이나 클라우드에 보관
- 복원: 같은 페이지의 **불러오기**로 JSON 파일 선택

---

## 트러블슈팅

**Q. 홈 화면에 추가했는데 일반 북마크처럼 보임**
A. Safari 외 다른 브라우저(Chrome, Naver 앱 등)에서는 PWA로 설치되지 않음. 반드시 **Safari**에서 열고 추가해야 해.

**Q. 페이지가 흰 화면만 나옴**
A. JavaScript가 로드되지 않은 경우. `shared.js`와 `shared.css`가 다른 HTML 파일과 같은 폴더에 있는지 확인.

**Q. 글꼴이 어색해 보임**
A. 첫 접속 때 Google Fonts를 다운받아 캐시함. 인터넷 연결 후 한 번 새로고침하면 정상화됨.

**Q. PC 브라우저로 미리 확인하고 싶음**
A. 방법 3과 동일하게 로컬 서버를 띄우거나, 파일을 두 번 클릭으로 열어도 작동(단, 모바일 설치 전 기능 확인용으로만).
