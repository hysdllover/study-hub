// Study Hub Service Worker — offline cache
const CACHE_NAME = 'study-hub-v1';
const ASSETS = [
  './',
  './index.html',
  './subjects.html',
  './note.html',
  './wrong.html',
  './flashcard.html',
  './checklist.html',
  './planner.html',
  './mock.html',
  './shared.css',
  './shared.js',
  './manifest.json'
];

// Install: pre-cache all assets
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS))
  );
  self.skipWaiting();
});

// Activate: clean old caches
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// Fetch: cache-first for app assets, network-first for fonts
self.addEventListener('fetch', event => {
  const req = event.request;
  const url = new URL(req.url);

  // Google Fonts: network-first, fall back to cache
  if (url.hostname === 'fonts.googleapis.com' || url.hostname === 'fonts.gstatic.com') {
    event.respondWith(
      fetch(req).then(res => {
        const clone = res.clone();
        caches.open(CACHE_NAME).then(c => c.put(req, clone));
        return res;
      }).catch(() => caches.match(req))
    );
    return;
  }

  // App shell: cache-first
  event.respondWith(
    caches.match(req).then(cached => cached || fetch(req).then(res => {
      // Cache successful same-origin responses
      if (res.ok && url.origin === self.location.origin) {
        const clone = res.clone();
        caches.open(CACHE_NAME).then(c => c.put(req, clone));
      }
      return res;
    }).catch(() => caches.match('./index.html')))
  );
});
